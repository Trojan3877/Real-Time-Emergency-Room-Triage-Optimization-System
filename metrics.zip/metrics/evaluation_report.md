
# Model Evaluation Report

## Version: 1.0 (July 2025)

### Dataset:
- Patients: 10,000 ER visits
- Features: Heart rate, BP, Resp. rate, Temperature, Triage outcome

### Metrics:
| Metric         | Value    |
|----------------|----------|
| Accuracy       | 92%      |
| F1 Score       | 0.90     |
| Precision      | 0.89     |
| Recall         | 0.91     |
| AUC-ROC        | 0.95     |

### Confusion Matrix:
![Confusion Matrix](confusion_matrix.png)

---

### Feature Importance (Top 5)
| Feature         | Importance |
|-----------------|------------|
| Heart Rate      | 0.35       |
| Temperature     | 0.27       |
| BP Systolic     | 0.18       |
| Resp. Rate      | 0.12       |
| BP Diastolic    | 0.08       |
