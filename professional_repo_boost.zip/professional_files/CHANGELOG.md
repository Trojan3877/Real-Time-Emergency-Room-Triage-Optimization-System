# Changelog

## [1.0.0] - 2025-07-11
- Initial release: end-to-end ML pipeline, API, docs, CI/CD, and production setup.
