# Contributing Guidelines

Thank you for your interest in contributing!

- Fork the repo and create your branch (`git checkout -b feature/fooBar`).
- Write clear, concise commit messages.
- Ensure code passes all tests and linting (`make test && make lint`).
- Document any changes in README or metrics/docs if relevant.
- Submit a pull request with a clear description of changes.
