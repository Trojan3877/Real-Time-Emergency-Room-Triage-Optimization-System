import requests

def test_api_predict():
    url = 'http://localhost:8000/predict'
    payload = {
        'heart_rate': 110,
        'bp_sys': 130,
        'bp_dia': 88,
        'resp_rate': 22,
        'temperature': 101.3
    }
    resp = requests.post(url, json=payload)
    assert resp.status_code == 200
    assert 'triage_level' in resp.json()
