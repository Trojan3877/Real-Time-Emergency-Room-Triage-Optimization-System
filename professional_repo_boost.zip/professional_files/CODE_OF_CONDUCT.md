# Code of Conduct

Be respectful, inclusive, and constructive in all interactions.
Report any abusive or inappropriate behavior to the repo maintainer.
Everyone is welcome to contribute and collaborate.
