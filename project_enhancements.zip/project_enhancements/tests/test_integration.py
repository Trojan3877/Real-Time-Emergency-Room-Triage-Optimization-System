
import requests

def test_end_to_end():
    # Health check endpoint
    health = requests.get("http://localhost:8000/health")
    assert health.status_code == 200
    data = health.json()
    assert data.get("status") == "ok"

    # Prediction endpoint
    payload = {
        "heart_rate": 110,
        "bp_sys": 130,
        "bp_dia": 88,
        "resp_rate": 22,
        "temperature": 101.3
    }
    resp = requests.post("http://localhost:8000/predict", json=payload)
    assert resp.status_code == 200
    result = resp.json()
    assert result["triage_level"] in ["moderate", "severe", "critical"]
    assert 0.0 <= result["confidence"] <= 1.0
