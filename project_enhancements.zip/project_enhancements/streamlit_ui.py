
import streamlit as st
import requests

st.title("ER Triage Optimization Demo")

hr = st.slider("Heart Rate", 60, 180, 90)
bps = st.slider("Systolic BP", 80, 200, 120)
bpd = st.slider("Diastolic BP", 40, 120, 80)
rr = st.slider("Respiration Rate", 10, 40, 20)
temp = st.slider("Temperature (°F)", 95.0, 105.0, 98.6)

if st.button("Predict Triage Level"):
    payload = {
        "heart_rate": hr,
        "bp_sys": bps,
        "bp_dia": bpd,
        "resp_rate": rr,
        "temperature": temp
    }
    resp = requests.post("http://localhost:8000/predict", json=payload)
    if resp.status_code == 200:
        result = resp.json()
        st.success(f"Triage Level: {result['triage_level']} (Confidence: {result['confidence']*100:.1f}%)")
    else:
        st.error("Prediction failed.")
