from fastapi import FastAPI, HTTPException, Security
from fastapi.security.api_key import APIKeyHeader
import os

API_KEY = os.getenv("API_KEY", "your_api_key_here")
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

app = FastAPI()

def get_api_key(api_key_header_value: str = Security(api_key_header)):
    if api_key_header_value == API_KEY:
        return api_key_header_value
    else:
        raise HTTPException(status_code=403, detail="Invalid API Key")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict(data: dict, api_key: str = Security(get_api_key)):
    # your prediction logic here
    return {"triage_level": "moderate", "confidence": 0.85}
